import os
import sys

# Ensure /app is in path
sys.path.append("/app")

import redis
from rq import Worker, Queue, Connection
from app.core.config import settings

listen = ['default']
redis_url = settings.REDIS_URL

# Preload libraries?
# import app.services.pipeline 

if __name__ == '__main__':
    print(f"Worker listening on {listen} via {redis_url}")
    conn = redis.from_url(redis_url)
    with Connection(conn):
        worker = Worker(list(map(Queue, listen)))
        worker.work()
