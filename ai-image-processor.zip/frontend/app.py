import streamlit as st
import requests
import time
import os

# Env
API_URL = os.getenv("API_URL", "http://api:8000")

st.set_page_config(page_title="PixelForge AI", layout="wide")

st.title("PixelForge AI: Professional Image Optimizer")
st.markdown("### Docker-Powered • Async Processing • Real-ESRGAN")

with st.sidebar:
    st.header("⚙️ Configuration")
    upscale = st.toggle("Enable AI Upscaling", value=True)
    scale = st.selectbox("Upscale Factor", [2, 4], index=1, help="2x is much faster. 4x provides simpler details.")
    model_type = st.selectbox("AI Model", ["RealESRGAN_x4plus (General)", "RealESRGAN_x4plus_anime_6B (Anime/Art)"], index=0)
    
    st.divider()
    
    st.subheader("Resize (Optional)")

    width = st.number_input("Width (px)", min_value=0, value=0)
    height = st.number_input("Height (px)", min_value=0, value=0)
    
    st.divider()
    
    fmt = st.selectbox("Output Format", ["PNG", "JPEG", "WEBP"])
    quality = st.slider("Compression Quality (JPEG/WEBP only)", 10, 100, 90, help="Higher is better quality but larger file size. Ignored for PNG.")

uploaded_files = st.file_uploader("Upload Images", accept_multiple_files=True, type=['png', 'jpg', 'webp'])

if st.button("Start Processing 🚀", disabled=not uploaded_files):
    # Prepare payload
    files_payload = [('files', (f.name, f, f.type)) for f in uploaded_files]
    data_payload = {
        'upscale_enabled': str(upscale).lower(), # Form needs string bools mostly or auto-convert
        'upscale_factor': scale,
        'model_name': model_type.split(" ")[0],
        'resize_width': width if width > 0 else None,
        'resize_height': height if height > 0 else None,
        'output_format': fmt,
        'quality': quality
    }
    
    # Filter None values
    data_payload = {k: v for k, v in data_payload.items() if v is not None}
    
    with st.spinner("Uploading and creating job..."):
        try:
            res = requests.post(f"{API_URL}/jobs/create", files=files_payload, data=data_payload)
            if res.status_code == 200:
                job_data = res.json()
                job_id = job_data['job_id']
                st.success(f"Job Created! ID: {job_id}")
                
                # Polling
                progress_bar = st.progress(0)
                status_text = st.empty()
                
                while True:
                    status_res = requests.get(f"{API_URL}/jobs/{job_id}")
                    if status_res.status_code != 200:
                        st.error("Failed to check status")
                        break
                        
                    status_data = status_res.json()
                    status = status_data['status']
                    progress = status_data.get('progress', 0)
                    
                    progress_bar.progress(progress)
                    status_text.text(f"Status: {status.upper()} ({progress}%)")
                    
                    if status == "completed" or (status == "processing" and status_data.get('processed_files')):
                        # Show processed files
                        st.subheader("Results")
                        files = status_data.get('processed_files', [])
                        cols = st.columns(3)
                        for i, f in enumerate(files):
                            with cols[i % 3]:
                                # Get full URL
                                file_url = f"{API_URL}{f['url']}"
                                st.image(file_url, caption=f['filename'], use_column_width=True)
                                
                                # Download Button for Individual
                                # Streamlit needs bytes for download button
                                # We can link to it? No, st.download_button wants data.
                                # So we fetch it.
                                # Or use st.link_button if available (New streamlit feature).
                                # Using standard link:
                                st.markdown(f"[Download {f['filename']}]({file_url})", unsafe_allow_html=True)

                    if status == "completed":
                        st.success("Processing Complete!")
                        download_res = requests.get(f"{API_URL}/jobs/{job_id}/download")
                        if download_res.status_code == 200:
                            st.download_button(
                                label="Download ALL (ZIP) 📦",
                                data=download_res.content,
                                file_name=f"processed_{job_id}.zip",
                                mime="application/zip"
                            )
                        break
                        
                    if status == "failed":
                        st.error(f"Job Failed: {status_data.get('error')}")
                        break
                        
                    time.sleep(2)
            else:
                st.error(f"Error creating job: {res.text}")
        except Exception as e:
            st.error(f"Connection Error: {e}")

